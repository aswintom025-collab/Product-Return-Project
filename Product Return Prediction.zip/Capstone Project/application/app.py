import os
import joblib
import pandas as pd
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

# Initialize FastAPI app
app = FastAPI(
    title="E-Commerce Product Return Risk Predictor API",
    description="Backend API serving XGBoost machine learning model for predicting return risk.",
    version="1.0.0"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Model & Scaler globals
MODEL_DATA = None
MODEL = None
SCALER = None
THRESHOLD = 0.5
NUMERIC_FEATURES = []
BINARY_FLAGS = []
CATEGORICAL_FEATURES = []
FEATURE_NAMES_IN = []

MODEL_FILE_PATH = os.path.join(os.path.dirname(__file__), "model_data.joblib")


def load_ml_model():
    global MODEL_DATA, MODEL, SCALER, THRESHOLD, NUMERIC_FEATURES, BINARY_FLAGS, CATEGORICAL_FEATURES, FEATURE_NAMES_IN
    if not os.path.exists(MODEL_FILE_PATH):
        raise FileNotFoundError(f"Model file not found at {MODEL_FILE_PATH}")
    
    MODEL_DATA = joblib.load(MODEL_FILE_PATH)
    MODEL = MODEL_DATA['model']
    SCALER = MODEL_DATA['scaler']
    THRESHOLD = MODEL_DATA.get('threshold', 0.5)
    NUMERIC_FEATURES = MODEL_DATA.get('numeric_features', [])
    BINARY_FLAGS = MODEL_DATA.get('binary_flags', [])
    CATEGORICAL_FEATURES = MODEL_DATA.get('categorical_features', [])
    FEATURE_NAMES_IN = list(MODEL.feature_names_in_)

# Load model at module initialization
load_ml_model()

# Category definitions based on model
CATEGORICAL_OPTIONS = {
    'product_category': ['Beauty', 'Books', 'Electronics', 'Fashion', 'Home', 'Sports', 'Toys'],
    'sub_category': [
        'Academic', 'Accessories', 'Action Figures', 'Audio', 'Decor', 'Educational',
        'Fiction', 'Fitness', 'Footwear', 'Furniture', 'Haircare', 'Kids',
        'Kitchen', 'Laptops', 'Makeup', 'Men', 'Mobiles', 'Non-Fiction',
        'Outdoor', 'Outdoor Play', 'Skincare', 'Team Sports', 'Women'
    ],
    'brand': [f"Brand_{i}" for i in range(1, 31)],
    'fulfillment_type': ['Marketplace Fulfilled', 'Seller Fulfilled'],
    'payment_method': ['COD', 'Credit Card', 'Debit Card', 'UPI', 'Wallet']
}

NUMERIC_OPTIONS = {
    'discount_percent': {
        'label': 'Discount Percent',
        'unit': '%',
        'default': 20.0,
        'options': [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 40.0, 50.0, 60.0, 70.0]
    },
    'product_rating': {
        'label': 'Product Rating',
        'unit': '★',
        'default': 4.2,
        'options': [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.2, 4.5, 4.8, 5.0]
    },
    'review_count': {
        'label': 'Review Count',
        'unit': 'reviews',
        'default': 100,
        'options': [5, 15, 30, 50, 75, 100, 150, 250, 500, 1000]
    },
    'product_return_rate': {
        'label': 'Product Return Rate',
        'unit': '%',
        'default': 0.10,
        'options': [
            {'label': '0% (Never Returned)', 'value': 0.00},
            {'label': '5% (Very Low)', 'value': 0.05},
            {'label': '10% (Low)', 'value': 0.10},
            {'label': '15% (Average)', 'value': 0.15},
            {'label': '20% (Elevated)', 'value': 0.20},
            {'label': '30% (High Risk)', 'value': 0.30},
            {'label': '45% (Critical)', 'value': 0.45}
        ]
    },
    'category_return_rate': {
        'label': 'Category Return Rate',
        'unit': '%',
        'default': 0.12,
        'options': [
            {'label': '5% (Low)', 'value': 0.05},
            {'label': '8% (Below Avg)', 'value': 0.08},
            {'label': '12% (Average)', 'value': 0.12},
            {'label': '16% (Above Avg)', 'value': 0.16},
            {'label': '22% (High Risk)', 'value': 0.22}
        ]
    },
    'brand_return_rate': {
        'label': 'Brand Return Rate',
        'unit': '%',
        'default': 0.10,
        'options': [
            {'label': '3% (Very Low)', 'value': 0.03},
            {'label': '8% (Low)', 'value': 0.08},
            {'label': '13% (Average)', 'value': 0.13},
            {'label': '20% (High)', 'value': 0.20},
            {'label': '30% (Severe)', 'value': 0.30}
        ]
    },
    'defect_rate': {
        'label': 'Defect Rate',
        'unit': '%',
        'default': 0.02,
        'options': [
            {'label': '0% (Flawless)', 'value': 0.00},
            {'label': '2% (Standard)', 'value': 0.02},
            {'label': '5% (Moderate)', 'value': 0.05},
            {'label': '8% (High)', 'value': 0.08},
            {'label': '15% (Critical)', 'value': 0.15}
        ]
    },
    'seller_rating': {
        'label': 'Seller Rating',
        'unit': '★',
        'default': 4.5,
        'options': [2.0, 2.5, 3.0, 3.5, 4.0, 4.2, 4.5, 4.8, 5.0]
    },
    'seller_return_rate': {
        'label': 'Seller Return Rate',
        'unit': '%',
        'default': 0.10,
        'options': [
            {'label': '3% (Excellent)', 'value': 0.03},
            {'label': '8% (Good)', 'value': 0.08},
            {'label': '12% (Average)', 'value': 0.12},
            {'label': '18% (Elevated)', 'value': 0.18},
            {'label': '25% (High Risk)', 'value': 0.25}
        ]
    },
    'quantity': {
        'label': 'Order Quantity',
        'unit': 'units',
        'default': 1,
        'options': [1, 2, 3, 4, 5, 8, 10]
    },
    'shipping_distance_km': {
        'label': 'Shipping Distance',
        'unit': 'km',
        'default': 500,
        'options': [50, 100, 250, 500, 750, 1000, 1500, 2000]
    },
    'product_page_views': {
        'label': 'Product Page Views',
        'unit': 'views',
        'default': 15,
        'options': [1, 3, 5, 10, 15, 20, 30, 50]
    },
    'total_customer_support': {
        'label': 'Support Contact Count',
        'unit': 'calls',
        'default': 0,
        'options': [0, 1, 2, 3, 4, 5]
    },
    'price_usd': {
        'label': 'Item Price ($ USD)',
        'unit': '$',
        'default': 150,
        'options': [
            {'label': '$15 (Budget)', 'value': 15, 'log_price': 2.71},
            {'label': '$50 (Standard)', 'value': 50, 'log_price': 3.91},
            {'label': '$100 (Mid-Range)', 'value': 100, 'log_price': 4.61},
            {'label': '$250 (Premium)', 'value': 250, 'log_price': 5.52},
            {'label': '$500 (High-End)', 'value': 500, 'log_price': 6.21},
            {'label': '$1000 (Luxury)', 'value': 1000, 'log_price': 6.91},
            {'label': '$2500 (Ultra)', 'value': 2500, 'log_price': 7.82}
        ]
    }
}


class PredictionInput(BaseModel):
    # Numeric features
    discount_percent: float = Field(20.0, description="Discount percentage (0 to 100)")
    product_rating: float = Field(4.2, description="Product rating (1.0 to 5.0)")
    review_count: float = Field(100.0, description="Number of product reviews")
    product_return_rate: float = Field(0.10, description="Historical product return rate (0.0 to 1.0)")
    category_return_rate: float = Field(0.12, description="Category average return rate (0.0 to 1.0)")
    brand_return_rate: float = Field(0.10, description="Brand average return rate (0.0 to 1.0)")
    defect_rate: float = Field(0.02, description="Item defect rate (0.0 to 1.0)")
    seller_rating: float = Field(4.5, description="Seller overall rating (1.0 to 5.0)")
    seller_return_rate: float = Field(0.10, description="Seller return rate (0.0 to 1.0)")
    quantity: float = Field(1.0, description="Quantity ordered")
    shipping_distance_km: float = Field(500.0, description="Shipping distance in kilometers")
    product_page_views: float = Field(15.0, description="Number of times customer viewed page")
    total_customer_support: float = Field(0.0, description="Customer support inquiries prior to purchase")
    log_price: float = Field(5.0, description="Natural logarithm of price (or computed from price)")

    # Binary flags (0 or 1)
    fragile_item: int = Field(0, description="Is item fragile (0=No, 1=Yes)")
    warranty_available: int = Field(1, description="Is warranty available (0=No, 1=Yes)")
    delayed_delivery: int = Field(0, description="Was delivery delayed (0=No, 1=Yes)")
    wishlist_before_purchase: int = Field(1, description="Was item wishlisted before buying (0=No, 1=Yes)")

    # Categorical features
    product_category: str = Field('Electronics', description="Product main category")
    sub_category: str = Field('Audio', description="Product sub category")
    brand: str = Field('Brand_5', description="Product brand name")
    fulfillment_type: str = Field('Marketplace Fulfilled', description="Fulfillment method")
    payment_method: str = Field('Credit Card', description="Payment method used")


@app.get("/api/features")
def get_features_metadata():
    """Returns dropdown options, defaults, and preset profiles for building UI controls."""
    presets = {
        'low_risk': {
            'name': 'Low Risk Order Profile',
            'data': {
                'discount_percent': 10.0,
                'product_rating': 4.8,
                'review_count': 250,
                'product_return_rate': 0.05,
                'category_return_rate': 0.08,
                'brand_return_rate': 0.03,
                'defect_rate': 0.00,
                'seller_rating': 4.8,
                'seller_return_rate': 0.03,
                'quantity': 1,
                'shipping_distance_km': 100,
                'product_page_views': 20,
                'total_customer_support': 0,
                'log_price': 4.61,  # ~$100
                'fragile_item': 0,
                'warranty_available': 1,
                'delayed_delivery': 0,
                'wishlist_before_purchase': 1,
                'product_category': 'Electronics',
                'sub_category': 'Audio',
                'brand': 'Brand_10',
                'fulfillment_type': 'Marketplace Fulfilled',
                'payment_method': 'Credit Card'
            }
        },
        'high_risk': {
            'name': 'High Risk Order Profile',
            'data': {
                'discount_percent': 50.0,
                'product_rating': 2.5,
                'review_count': 15,
                'product_return_rate': 0.30,
                'category_return_rate': 0.22,
                'brand_return_rate': 0.20,
                'defect_rate': 0.08,
                'seller_rating': 3.0,
                'seller_return_rate': 0.25,
                'quantity': 5,
                'shipping_distance_km': 1500,
                'product_page_views': 3,
                'total_customer_support': 3,
                'log_price': 6.91,  # ~$1000
                'fragile_item': 1,
                'warranty_available': 0,
                'delayed_delivery': 1,
                'wishlist_before_purchase': 0,
                'product_category': 'Fashion',
                'sub_category': 'Footwear',
                'brand': 'Brand_25',
                'fulfillment_type': 'Seller Fulfilled',
                'payment_method': 'COD'
            }
        },
        'average_order': {
            'name': 'Average Order Profile',
            'data': {
                'discount_percent': 20.0,
                'product_rating': 4.2,
                'review_count': 100,
                'product_return_rate': 0.10,
                'category_return_rate': 0.12,
                'brand_return_rate': 0.10,
                'defect_rate': 0.02,
                'seller_rating': 4.2,
                'seller_return_rate': 0.10,
                'quantity': 2,
                'shipping_distance_km': 500,
                'product_page_views': 15,
                'total_customer_support': 1,
                'log_price': 5.52,  # ~$250
                'fragile_item': 0,
                'warranty_available': 1,
                'delayed_delivery': 0,
                'wishlist_before_purchase': 1,
                'product_category': 'Home',
                'sub_category': 'Decor',
                'brand': 'Brand_5',
                'fulfillment_type': 'Marketplace Fulfilled',
                'payment_method': 'UPI'
            }
        }
    }

    return {
        "model_name": MODEL_DATA.get('model_name', 'XGBoost Classifier'),
        "threshold": THRESHOLD,
        "categorical_options": CATEGORICAL_OPTIONS,
        "numeric_options": NUMERIC_OPTIONS,
        "binary_options": {
            'fragile_item': {'label': 'Fragile Item', 'options': [{'label': 'No (Standard Handling)', 'value': 0}, {'label': 'Yes (Fragile / Glass)', 'value': 1}]},
            'warranty_available': {'label': 'Warranty Available', 'options': [{'label': 'No Warranty', 'value': 0}, {'label': 'Yes (Warranty Covered)', 'value': 1}]},
            'delayed_delivery': {'label': 'Delivery Status', 'options': [{'label': 'On Time', 'value': 0}, {'label': 'Delayed Delivery', 'value': 1}]},
            'wishlist_before_purchase': {'label': 'Wishlist History', 'options': [{'label': 'Direct Impulse Buy', 'value': 0}, {'label': 'Wishlisted First', 'value': 1}]}
        },
        "presets": presets
    }


@app.post("/api/predict")
def predict_return_risk(input_data: PredictionInput):
    """Predict product return risk given user selections."""
    try:
        input_dict = input_data.dict()

        # 1. Scaled Numeric DataFrame
        num_vals = [input_dict[f] for f in NUMERIC_FEATURES]
        num_df = pd.DataFrame([num_vals], columns=NUMERIC_FEATURES)
        num_scaled = SCALER.transform(num_df)

        # 2. Build full feature vector dictionary (85 features)
        row_dict = {}
        for i, col in enumerate(NUMERIC_FEATURES):
            row_dict[col] = num_scaled[0, i]

        for col in BINARY_FLAGS:
            row_dict[col] = float(input_dict[col])

        # One-hot encoding for categorical features matching model feature names
        for feat in FEATURE_NAMES_IN:
            if feat in row_dict:
                continue
            matched = False
            for cat_col in CATEGORICAL_FEATURES:
                prefix = cat_col + '_'
                if feat.startswith(prefix):
                    val = feat[len(prefix):]
                    row_dict[feat] = 1.0 if input_dict.get(cat_col) == val else 0.0
                    matched = True
                    break
            if not matched:
                row_dict[feat] = 0.0

        # Construct feature vector in exact order expected by XGBoost
        df_final = pd.DataFrame([[row_dict[col] for col in FEATURE_NAMES_IN]], columns=FEATURE_NAMES_IN)

        # Predict probability
        probabilities = MODEL.predict_proba(df_final)[0]
        return_probability = float(probabilities[1])
        prediction_class = int(return_probability >= THRESHOLD)

        # Calculate risk classification level
        if return_probability < 0.25:
            risk_level = "Low Risk"
            risk_color = "emerald"
            recommendation = "Low probability of return. High customer satisfaction expected."
        elif return_probability < 0.50:
            risk_level = "Moderate Risk"
            risk_color = "amber"
            recommendation = "Moderate return probability. Consider quality checks or optimized logistics."
        else:
            risk_level = "High Risk"
            risk_color = "rose"
            recommendation = "High risk of product return. Proactive support or inspection recommended."

        # Extract top risk factors driving the prediction
        key_factors = []
        if input_dict.get('delayed_delivery') == 1:
            key_factors.append("Delivery is marked as delayed (significantly increases return risk).")
        if input_dict.get('defect_rate', 0) > 0.04:
            key_factors.append(f"Elevated product defect rate ({input_dict['defect_rate']*100:.1f}%).")
        if input_dict.get('product_return_rate', 0) > 0.15:
            key_factors.append(f"High historical product return rate ({input_dict['product_return_rate']*100:.1f}%).")
        if input_dict.get('seller_return_rate', 0) > 0.15:
            key_factors.append(f"Seller has a high return rate ({input_dict['seller_return_rate']*100:.1f}%).")
        if input_dict.get('product_rating', 5.0) < 3.5:
            key_factors.append(f"Low product rating ({input_dict['product_rating']} / 5.0).")
        if input_dict.get('total_customer_support', 0) >= 2:
            key_factors.append(f"Multiple customer support inquiries ({input_dict['total_customer_support']} contacts).")
        if input_dict.get('warranty_available') == 0:
            key_factors.append("No warranty available on purchase.")
        if input_dict.get('fulfillment_type') == 'Seller Fulfilled':
            key_factors.append("Seller fulfillment (higher return probability vs marketplace fulfilled).")
        
        if not key_factors:
            key_factors.append("Favorable seller ratings and standard order parameters.")

        return {
            "success": True,
            "prediction": prediction_class,
            "prediction_label": "Returned" if prediction_class == 1 else "Kept",
            "probability": round(return_probability, 4),
            "probability_percentage": f"{return_probability * 100:.1f}%",
            "threshold": THRESHOLD,
            "risk_level": risk_level,
            "risk_color": risk_color,
            "recommendation": recommendation,
            "key_factors": key_factors
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")


# Serve static web interface
static_path = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_path):
    app.mount("/static", StaticFiles(directory=static_path), name="static")

@app.get("/")
def serve_index():
    index_file = os.path.join(static_path, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "API operational. Frontend index.html not found."}
