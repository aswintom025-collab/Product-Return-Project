// Frontend JavaScript Logic for Return Risk Predictor

let featureMetadata = null;

document.addEventListener('DOMContentLoaded', async () => {
  await fetchMetadataAndInit();

  const form = document.getElementById('predictForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    await handlePrediction();
  });
});

/**
 * Fetch feature metadata from backend API and populate dropdown controls
 */
async function fetchMetadataAndInit() {
  try {
    const res = await fetch('/api/features');
    if (!res.ok) throw new Error('Failed to fetch model feature metadata');
    featureMetadata = await res.json();

    populateCategoricalDropdowns(featureMetadata.categorical_options);
    populateBinaryDropdowns(featureMetadata.binary_options);
    populateNumericDropdowns(featureMetadata.numeric_options);

    // Initial prediction run with defaults
    await handlePrediction();

  } catch (err) {
    console.error('Initialization error:', err);
  }
}

function populateCategoricalDropdowns(optionsMap) {
  for (const [field, list] of Object.entries(optionsMap)) {
    const select = document.getElementById(field);
    if (!select) continue;
    select.innerHTML = '';
    list.forEach((item, index) => {
      const opt = document.createElement('option');
      opt.value = item;
      opt.textContent = item;
      if (index === 0) opt.selected = true;
      select.appendChild(opt);
    });
  }
}

function populateBinaryDropdowns(binaryMap) {
  for (const [field, info] of Object.entries(binaryMap)) {
    const select = document.getElementById(field);
    if (!select) continue;
    select.innerHTML = '';
    info.options.forEach(item => {
      const opt = document.createElement('option');
      opt.value = item.value;
      opt.textContent = item.label;
      select.appendChild(opt);
    });
  }
}

function populateNumericDropdowns(numericMap) {
  for (const [field, info] of Object.entries(numericMap)) {
    const select = document.getElementById(field);
    if (!select) continue;
    select.innerHTML = '';
    
    info.options.forEach(item => {
      const opt = document.createElement('option');
      if (typeof item === 'object') {
        opt.value = item.value;
        opt.textContent = item.label;
        if (item.log_price) {
          opt.dataset.logPrice = item.log_price;
        }
        if (item.value === info.default) opt.selected = true;
      } else {
        opt.value = item;
        opt.textContent = `${item} ${info.unit ? info.unit : ''}`.trim();
        if (item === info.default) opt.selected = true;
      }
      select.appendChild(opt);
    });
  }
}

/**
 * Handle form prediction request
 */
async function handlePrediction() {
  const overlay = document.getElementById('loadingOverlay');
  overlay.style.display = 'flex';

  try {
    // Gather values from all dropdown boxes
    const priceSelect = document.getElementById('price_usd');
    const selectedPriceOpt = priceSelect.options[priceSelect.selectedIndex];
    
    let computedLogPrice = 5.0;
    if (selectedPriceOpt && selectedPriceOpt.dataset.logPrice) {
      computedLogPrice = parseFloat(selectedPriceOpt.dataset.logPrice);
    } else if (priceSelect.value) {
      computedLogPrice = Math.log(parseFloat(priceSelect.value));
    }

    const payload = {
      product_category: document.getElementById('product_category').value,
      sub_category: document.getElementById('sub_category').value,
      brand: document.getElementById('brand').value,
      product_rating: parseFloat(document.getElementById('product_rating').value),
      review_count: parseFloat(document.getElementById('review_count').value),
      discount_percent: parseFloat(document.getElementById('discount_percent').value),
      log_price: computedLogPrice,
      seller_rating: parseFloat(document.getElementById('seller_rating').value),
      defect_rate: parseFloat(document.getElementById('defect_rate').value),
      product_return_rate: parseFloat(document.getElementById('product_return_rate').value),
      category_return_rate: parseFloat(document.getElementById('category_return_rate').value),
      brand_return_rate: parseFloat(document.getElementById('brand_return_rate').value),
      seller_return_rate: parseFloat(document.getElementById('seller_return_rate').value),
      fulfillment_type: document.getElementById('fulfillment_type').value,
      payment_method: document.getElementById('payment_method').value,
      shipping_distance_km: parseFloat(document.getElementById('shipping_distance_km').value),
      quantity: parseFloat(document.getElementById('quantity').value),
      fragile_item: parseInt(document.getElementById('fragile_item').value),
      delayed_delivery: parseInt(document.getElementById('delayed_delivery').value),
      product_page_views: parseFloat(document.getElementById('product_page_views').value),
      total_customer_support: parseFloat(document.getElementById('total_customer_support').value),
      warranty_available: parseInt(document.getElementById('warranty_available').value),
      wishlist_before_purchase: parseInt(document.getElementById('wishlist_before_purchase').value)
    };

    const res = await fetch('/api/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) throw new Error('Prediction API call failed');
    const result = await res.json();

    updateUI(result);

  } catch (err) {
    console.error('Prediction error:', err);
  } finally {
    setTimeout(() => {
      overlay.style.display = 'none';
    }, 200);
  }
}

/**
 * Update UI elements with model result
 */
function updateUI(res) {
  // Meter Fill: max dashoffset = 283 (0% prob), min dashoffset = 0 (100% prob)
  const meterFill = document.getElementById('meterFill');
  const prob = res.probability;
  const dashoffset = 283 - (prob * 283);
  meterFill.style.strokeDashoffset = dashoffset;

  // Set meter color matching risk level
  if (res.risk_color === 'emerald') {
    meterFill.style.stroke = '#10b981';
  } else if (res.risk_color === 'amber') {
    meterFill.style.stroke = '#f59e0b';
  } else {
    meterFill.style.stroke = '#f43f5e';
  }

  // Percentage Display
  document.getElementById('probDisplay').textContent = res.probability_percentage;

  // Risk Pill
  const riskPill = document.getElementById('riskPill');
  riskPill.className = `risk-pill ${res.risk_color}`;
  riskPill.innerHTML = `<span>●</span> ${res.risk_level.toUpperCase()}`;

  // Prediction Class Outcome
  const outcomeText = document.getElementById('outcomeText');
  outcomeText.textContent = res.prediction === 1 ? '⚠️ Likely to be Returned' : '✅ Likely to be Kept';

  // Recommendation
  document.getElementById('recommendationText').textContent = res.recommendation;

  // Key Factors
  const factorsList = document.getElementById('factorsList');
  factorsList.innerHTML = '';
  res.key_factors.forEach(factor => {
    const li = document.createElement('li');
    li.className = 'factor-item';
    li.textContent = factor;
    factorsList.appendChild(li);
  });
}

/**
 * Apply sample preset profile
 */
function applyPreset(presetKey) {
  if (!featureMetadata || !featureMetadata.presets[presetKey]) return;
  const data = featureMetadata.presets[presetKey].data;

  for (const [key, val] of Object.entries(data)) {
    if (key === 'log_price') {
      // Map log_price back to closest price option
      const priceSelect = document.getElementById('price_usd');
      let minDiff = Infinity;
      let bestIndex = 0;
      for (let i = 0; i < priceSelect.options.length; i++) {
        const lp = parseFloat(priceSelect.options[i].dataset.logPrice || 0);
        const diff = Math.abs(lp - val);
        if (diff < minDiff) {
          minDiff = diff;
          bestIndex = i;
        }
      }
      priceSelect.selectedIndex = bestIndex;
      continue;
    }

    const elem = document.getElementById(key);
    if (elem) {
      elem.value = val;
    }
  }

  // Automatically recalculate
  handlePrediction();
}

/**
 * Reset all dropdowns to default preset
 */
function resetForm() {
  applyPreset('average_order');
}
